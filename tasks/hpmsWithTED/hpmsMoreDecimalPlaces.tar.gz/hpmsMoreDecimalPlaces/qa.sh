#!/bin/bash

set -e

pushd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null

while read -r COL; do
  SQL="
    SELECT
        Travel_Time_Code,
        new.${COL} AS new_${COL},
        old.${COL} AS old_${COL},
        (new.${COL} - old.${COL}) AS diff
        FROM new INNER JOIN old USING (Travel_Time_Code)
      WHERE (
        ABS(
          ROUND(new.${COL}, 1) - ROUND(old.${COL}, 1)
        ) >= 1
      )
    ;
  "
  echo "===== ${COL} ====="

  csvsql --table new,old \
    --query "${SQL}" \
    ./ny.2017.hpms-pm3.20180925.csv \
    ./tt2.new.csv
    

  echo
done < ./measure-columns

